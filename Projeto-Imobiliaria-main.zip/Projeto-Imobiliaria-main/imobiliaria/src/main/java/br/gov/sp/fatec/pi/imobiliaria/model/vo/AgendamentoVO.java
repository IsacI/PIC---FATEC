package br.gov.sp.fatec.pi.imobiliaria.model.vo;

public class AgendamentoVO {
}
